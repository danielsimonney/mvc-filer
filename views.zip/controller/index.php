
<!-- Et enfin c'est ici le controller -->

<?php




require("../models/tv_show.php");

function putInArrayFolder($mypath){
    $foldertab=[];
  $files = scandir($mypath); 
  foreach($files as $file)
  {
      
      if(is_dir($mypath. "/" . $file)){
        if($file != "." && $file != ".." ){
  array_push($foldertab,$file);
        }
      }
  }
  return($foldertab);
  }
   
  function putInArrayFiles($mypath){
    $filetab=[];
    $files = scandir($mypath); 
    foreach($files as $file)
    {
        
        if(is_file($mypath. "/" . $file)){
    array_push($filetab,$file);
    
        }
    }
    return($filetab);
    }

    if(isset($_GET['retouraudebut'])){

    }
    if (isset($_GET['myentirepath'])){
    
    $path=($_GET['myentirepath']);
    $myfiletab=(putInArrayFiles($path));
      $myfoldertab=(putInArrayFolder($path));
    
    
    }else{
    
      $path=$pathbeginning;
      $myfiletab=(putInArrayFiles($pathbeginning));
      $myfoldertab=(putInArrayFolder($pathbeginning));
    }
    
    
    if(isset($_GET['retour'])){
    
      $path=dirname($_GET['retour']);  
      var_dump($_GET['retour']);
      $myfiletab=(putInArrayFiles($path));
        $myfoldertab=(putInArrayFolder($path)); 
    }

    if (isset($_POST['foldername']))
{
    mkdir(($path."/".$_POST['foldername']), 0700);
}





require('../views/index_home.php');